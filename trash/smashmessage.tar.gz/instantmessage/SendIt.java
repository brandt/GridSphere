/*
 * @author <a href="mailto:oliver@wehrens.de">Oliver Wehrens</a>
 * @team sonicteam
 * $Id: SendIt.java,v 1.1 2002/11/11 14:18:00 wehrens Exp $
 */
package org.gridlab.instantmessage;

public class SendIt {
    public static void main(String[] args) {

        JabberNotifier not = new JabberNotifier();

        try {
            not.notify("header", "subjesssct","owehrens");
        } catch (InstantMessageException e) {
            e.printStackTrace();  //To change body of catch statement use Options | File Templates.
        }

    }
}
