/*
 * @author <a href="mailto:oliver@wehrens.de">Oliver Wehrens</a>
 * @team sonicteam
 * $Id: JabberNotifier.java,v 1.1 2002/11/11 14:18:00 wehrens Exp $
 */
package org.gridlab.instantmessage;

// later we maybe going to have a notification framework

public class JabberNotifier {

    private JabberBot bot;

    public JabberNotifier() {
        bot = JabberBot.getInstance();
    }

    public void notify(String subject, String message, String user) throws InstantMessageException {
        bot.sendMessage(" ", message, user);
    }
}
