/*
 * @author <a href="mailto:oliver@wehrens.de">Oliver Wehrens</a>
 * @team sonicteam
 * $Id: InstantMessageException.java,v 1.1 2002/11/11 14:18:00 wehrens Exp $
 */

package org.gridlab.instantmessage;

public class InstantMessageException extends Exception {

    public InstantMessageException () {
        super();
    }

    public InstantMessageException(String msg) {
        super(msg);
    }
}
