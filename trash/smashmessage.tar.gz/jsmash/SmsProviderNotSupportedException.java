/*
 * @author <a href="mailto:oliver@wehrens.de">Oliver Wehrens</a>
 * @team sonicteam
 * @version $Id: SmsProviderNotSupportedException.java,v 1.1 2002/10/23 15:39:14 wehrens Exp $
 */

package org.gridlab.jsmash;

public class SmsProviderNotSupportedException extends Exception {

    public SmsProviderNotSupportedException() {
        super();
    }

    public SmsProviderNotSupportedException(String msg) {
        super(msg);
    }
}

