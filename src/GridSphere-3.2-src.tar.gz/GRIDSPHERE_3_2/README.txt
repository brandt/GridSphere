$Id: README.txt 6500 2010-11-04 13:53:38Z koholka $

	Welcome to GridSphere! 
========================================

Please follow the instructions in the INSTALL file to build GridSphere.

Information about Shibboleth you find in the SHIBBOLETH file.
Information about X.509 certificates you find in the X509 file.

You can also check the online web site 
(http://www.gridsphere.org) which contains the most up to date 
information including slides, white papers, and other documentation on 
using GridSphere and developing portlets. Please check out the slides
available at http://www.gridsphere.org/gridsphere/gridsphere?cid=docs which
describe how to set and install GridSphere as well as portlet development 
and deployment

In addition, please subscribe to the following mail lists from the mailman
interface at http://lists.gridsphere.org/mailman/listinfo:

gridsphere-users -- Mail list used for the discussion of developing portals using the GridSphere framework

gridsphere-dev -- Mail list used for the discussion of GridSphere framework development

gridsphere-cvs -- Mail list used to receive CVS notifications

To report bugs, please use the bugtracker at http://bugs.gridsphere.org

 Thank you.

The GridSphere Team	http://www.gridsphere.org






