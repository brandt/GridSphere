$Id: README.txt 4496 2006-02-08 20:27:04Z wehrens $

This directory contains all the third-party libraries required for the compilation/deployment of GridSphere. All licenses are open source and cann be found in the licenses directory.





