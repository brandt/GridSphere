/*
 * @author <a href="mailto:novotny@gridsphere.org">Jason Novotny</a>
 * @version $Id: LengthValidator.java 6385 2007-10-25 14:02:26Z wehrens $
 */
package org.gridsphere.provider.portletui.validator;

public class LengthValidator extends BaseValidator {

    public boolean isValid() {
        return true;
    }

}
