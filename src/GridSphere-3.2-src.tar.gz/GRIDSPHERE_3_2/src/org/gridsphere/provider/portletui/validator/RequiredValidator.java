/*
 * @author <a href="mailto:novotny@gridsphere.org">Jason Novotny</a>
 * @version $Id: RequiredValidator.java 6385 2007-10-25 14:02:26Z wehrens $
 */
package org.gridsphere.provider.portletui.validator;

public class RequiredValidator extends BaseValidator {

    public boolean isValid() {
        return true;
    }

}
