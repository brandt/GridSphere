/*
 * Created by IntelliJ IDEA.
 * User: novotny
 * Date: Jan 14, 2003
 * Time: 10:25:56 PM
 * To change template for new interface use
 * Code Style | Class Templates options (Tools | IDE Options).
 */
package org.gridsphere.provider.portletui.validator;

public interface Validator {

    public boolean isValid();

}
