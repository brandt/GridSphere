/**
 * @author <a href="mailto:michael.russell@aei.mpg.de">Michael Russell</a>
 * @version $Id: ActionPaneTag.java 6385 2007-10-25 14:02:26Z wehrens $
 */
package org.gridsphere.provider.portletui.tags;

/**
 * Contains action menu and action body.
 */
public class ActionPaneTag extends ActionMenuTag {

    public ActionPaneTag() {
        super();
    }
}
