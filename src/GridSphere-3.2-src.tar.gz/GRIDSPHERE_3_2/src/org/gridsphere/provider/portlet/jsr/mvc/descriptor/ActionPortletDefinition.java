/**
 * @author <a href="mailto:novotny@gridsphere.org">Jason Novotny</a>
 * @version $Id: ActionPortletDefinition.java 6385 2007-10-25 14:02:26Z wehrens $
 */
package org.gridsphere.provider.portlet.jsr.mvc.descriptor;

import java.util.List;

public class ActionPortletDefinition {

    private String name = "";
    private List pageList = null;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List getPageList() {
        return pageList;
    }

    public void setPageList(List pageList) {
        this.pageList = pageList;
    }
    

}