/**
 * @author <a href="mailto:novotny@gridsphere.org">Jason Novotny</a>
 * @version $Id: ResultDefinition.java 6385 2007-10-25 14:02:26Z wehrens $
 */
package org.gridsphere.provider.portlet.jsr.mvc.descriptor;

public class ResultDefinition {

    private String result = "";
    private String state = "";

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }


}

