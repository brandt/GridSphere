/**
 * @author <a href="mailto:novotny@gridsphere.org">Jason Novotny</a>
 * @version $Id: ActionPortletCollection.java 6385 2007-10-25 14:02:26Z wehrens $
 */
package org.gridsphere.provider.portlet.jsr.mvc.descriptor;

import java.util.List;

public class ActionPortletCollection {

    private List actionPortletList = null;

    public List getActionPortletList() {
        return actionPortletList;
    }

    public void setActionPortletList(List actionPortletList) {
        this.actionPortletList = actionPortletList;
    }

}