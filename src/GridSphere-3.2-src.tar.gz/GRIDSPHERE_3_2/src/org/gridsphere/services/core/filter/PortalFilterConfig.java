package org.gridsphere.services.core.filter;

/**
 * @author <a href="mailto:novotny@gridsphere.org">Jason Novotny</a>
 * @version $Id: PortalFilterConfig.java 6385 2007-10-25 14:02:26Z wehrens $
 */
public interface PortalFilterConfig {

    public String getInitParameter(String name);

}
