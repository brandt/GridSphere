package org.gridsphere.services.core.security.auth.modules.impl;

/**
 * @author <a href="mailto:docentt@man.poznan.pl">Tomasz Kuczynski</a>, PSNC
 * @version $Id: UserDescriptor.java 6385 2007-10-25 14:02:26Z wehrens $
 */
public class UserDescriptor {
    private String emailAddress;
    private String ID;
    private String userName;

    public UserDescriptor(String emailAddress, String userID, String userName) {
        this.emailAddress = emailAddress;
        this.ID = userID;
        this.userName = userName;
    }

    public String getEmailAddress() {
        return emailAddress;
    }

    public String getID() {
        return ID;
    }

    public String getUserName() {
        return userName;
    }
}
