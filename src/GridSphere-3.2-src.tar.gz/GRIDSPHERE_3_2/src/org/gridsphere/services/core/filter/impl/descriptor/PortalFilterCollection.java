package org.gridsphere.services.core.filter.impl.descriptor;

import java.util.List;
import java.util.Vector;

/**
 * @author <a href="mailto:novotny@gridsphere.org">Jason Novotny</a>
 * @version $Id: PortalFilterCollection.java 6385 2007-10-25 14:02:26Z wehrens $
 */
public class PortalFilterCollection {

    private List<PortalFilterDefinition> portalFilterList = new Vector<PortalFilterDefinition>();

    public List<PortalFilterDefinition> getPortalFilterList() {
        return portalFilterList;
    }

    public void setPortalFilterList(List<PortalFilterDefinition> portalFilterList) {
        this.portalFilterList = portalFilterList;
    }

}
