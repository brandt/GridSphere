package org.gridsphere.services.core.security.auth.modules;

import org.gridsphere.services.core.security.auth.modules.impl.UserDescriptor;
import org.gridsphere.services.core.security.auth.modules.impl.AuthenticationParameters;

import java.util.Map;

/**
 * @author <a href="mailto:docentt@man.poznan.pl">Tomasz Kuczynski</a>, PSNC
 * @version $Id: LateUserRetrievalAuthModule.java 6385 2007-10-25 14:02:26Z wehrens $
 */
public interface LateUserRetrievalAuthModule extends LoginAuthModule {
    public UserDescriptor checkAuthentication(AuthenticationParameters authenticationParameters) throws Exception;
}
