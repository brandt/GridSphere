package org.gridsphere.services.core.content;

import java.io.File;
import java.io.IOException;

/**
 * @author <a href="mailto:novotny@gridsphere.org">Jason Novotny</a>
 * @version $Id: ContentFile.java 6385 2007-10-25 14:02:26Z wehrens $
 */
public interface ContentFile {

    public StringBuffer getContentBuffer() throws IOException;

    public File getFile();
}
