package org.gridsphere.services.core.filter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * @author <a href="mailto:novotny@gridsphere.org">Jason Novotny</a>
 * @version $Id: PortalFilter.java 6385 2007-10-25 14:02:26Z wehrens $
 */
public interface PortalFilter {

    public void init(PortalFilterConfig config);

    public void doAfterLogin(HttpServletRequest req, HttpServletResponse res);

    public void doAfterLogout(HttpServletRequest req, HttpServletResponse res);

    public void doBeforeEveryRequest(HttpServletRequest req, HttpServletResponse res);

    public void doAfterEveryRequest(HttpServletRequest req, HttpServletResponse res);

}
