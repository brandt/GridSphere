package org.gridsphere.portletcontainer;

/**
 * @author <a href="mailto:novotny@gridsphere.org">Jason Novotny</a>
 * @version $Id: PortletStatus.java 6385 2007-10-25 14:02:26Z wehrens $
 */
public class PortletStatus {

    public static PortletStatus SUCCESS = new PortletStatus("success");

    public static PortletStatus FAILURE = new PortletStatus("failure");

    private String status;

    private PortletStatus(String status) {
        this.status = status;
    }

    public boolean equals(Object o) {
        if ((o != null) && (o instanceof PortletStatus)) {
            return (this.status.equals(((PortletStatus) o).toString()));
        }
        return false;
    }

    public String toString() {
        return status;
    }
    public int hashCode() {
        return status.hashCode();
    }

}
